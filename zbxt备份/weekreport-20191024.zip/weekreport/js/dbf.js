window.onload = main;

function main() {
	InitSideBar();
}

function InitSideBar() {
	var sidebar = $(".sidebar > ul");

}