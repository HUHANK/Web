INSERT INTO `xgroup` (`id`, `name`, `manager`, `depart_id`) VALUES (12, '结算组', 4, 1);
INSERT INTO `xgroup` (`id`, `name`, `manager`, `depart_id`) VALUES (13, '交易组', 5, 1);
INSERT INTO `xgroup` (`id`, `name`, `manager`, `depart_id`) VALUES (14, '管理组', 24, 1);
INSERT INTO `xgroup` (`id`, `name`, `manager`, `depart_id`) VALUES (15, '周边组', 15, 1);
INSERT INTO `xgroup` (`id`, `name`, `manager`, `depart_id`) VALUES (16, '一人组', 3, 1);
