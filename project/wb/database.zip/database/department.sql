INSERT INTO `department` (`id`, `name`, `manager`) VALUES (1, '开发一部', 3);
