INSERT INTO `sys_param` (`id`, `ParamCode`, `ParamName`, `ParamValue`, `Note`) VALUES (1, '0001', '系统当前周期', '2018,12', '用于判断系统是否调整到下周');
INSERT INTO `sys_param` (`id`, `ParamCode`, `ParamName`, `ParamValue`, `Note`) VALUES (2, '0002', '转下周时间点', '5,12', '参数：1，星期几；2，时间（小时）');
